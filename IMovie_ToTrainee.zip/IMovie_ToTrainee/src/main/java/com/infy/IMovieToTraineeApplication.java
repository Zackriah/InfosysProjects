package com.infy;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;

import com.infy.model.Movie;
import com.infy.service.MovieService;



@SpringBootApplication
public class IMovieToTraineeApplication implements CommandLineRunner{

	@Autowired
	Environment environment;
	
	@Autowired
	MovieService service;
	
	public static void main(String[] args) {
		SpringApplication.run(IMovieToTraineeApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		addMovie();
		getMovies();
		updateRevenue();
		deleteMovie();
		
		
	}
	
	public void addMovie() {
		try {

			Movie movie = new Movie();

			movie.setMovieId("M1006");
			movie.setMovieName("3 Idiots");
			movie.setLanguage("Hindi");
			movie.setReleasedIn(2009);
			;
			movie.setRevenueInDollars(87000000);

			String movieId = service.addMovie(movie);
			System.out.println();
			System.out.print(environment.getProperty("UserInterface.INSERT_SUCCESS"));
			System.out.println(movieId);

		} catch (Exception e) {
			System.out.println(environment.getProperty(e.getMessage()));
		}
	}

	public void getMovies() {
		try {

			List<Movie> movies = service.getMovies(2000);
			if (movies != null) {
				System.out
						.println("MovieId       MovieName       Language		ReleasedOn		RevenueInDollars ");
				System.out
						.println("-------------------------------------------------------------------------------");
				for (Movie movie : movies) {
					System.out.println(movie.getMovieId() + "\t       "
							+ movie.getMovieName() + "\t    "
							+ movie.getLanguage() + "\t		"
							+ movie.getReleasedIn() + "\t		"
							+ movie.getRevenueInDollars());
				}
			}
			else
				System.out.println(environment.getProperty("UserInterface.NO_MOVIES"));
		} catch (Exception e) {
			System.out.println(environment.getProperty(e.getMessage()));
		}
	}

	public void updateRevenue() {
		try {

			Integer i = service.updateRevenue("M1005");
			System.out.println();
			if (i == 1) {
				System.out.print(environment.getProperty("UserInterface.UPDATE_SUCCESS"));
			} else {
				System.out.print(environment.getProperty("UserInterface.UPDATE_FAILURE"));
			}

		} catch (Exception e) {
			System.out.println(environment.getProperty(e.getMessage()));
		}
	}

	public void deleteMovie() {
		try {

			Integer i = service.deleteMovie("M1005");
			System.out.println();
			if (i == 1) {
				System.out.print(environment.getProperty("UserInterface.DELETE_SUCCESS"));
			} else {
				System.out.print(environment.getProperty("UserInterface.DELETE_FAILURE"));
			}

		} catch (Exception e) {
			System.out.println(environment.getProperty(e.getMessage()));
		}
	}


	
}

