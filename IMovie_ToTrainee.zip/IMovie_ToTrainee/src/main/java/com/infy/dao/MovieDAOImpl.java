package com.infy.dao;

import java.util.List;

import com.infy.model.Movie;



public class MovieDAOImpl implements MovieDAO {
	
	

	@Override
	public String findMovie(String movieId) throws Exception {

		return null;
	}



	@Override
	public String addMovie(Movie movie) throws Exception {

		return null;
	}




	@Override
	public List<Movie> getMovies(Integer year) throws Exception {

		return null;
	}




	@Override
	public Integer updateRevenue(String movieId) throws Exception {

		return null;
	}



	@Override
	public Integer deleteMovie(String movieId) throws Exception {


		return null;
	}

}