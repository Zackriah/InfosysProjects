package com.infy.dao;

import java.util.List;

import com.infy.model.Movie;

public interface MovieDAO {

	public String findMovie(String movieId) throws Exception;

	public String addMovie(Movie movie) throws Exception;

	public List<Movie> getMovies(Integer year) throws Exception;

	public Integer updateRevenue(String movieId) throws Exception;

	public Integer deleteMovie(String movieId) throws Exception;

}
