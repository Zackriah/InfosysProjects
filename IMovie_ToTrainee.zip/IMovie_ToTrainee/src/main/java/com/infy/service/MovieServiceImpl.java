package com.infy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dao.MovieDAO;
import com.infy.model.Movie;


@Service(value="movieService")
public class MovieServiceImpl implements MovieService {
	
	@Autowired
	private MovieDAO movieDao;
	

	@Override
	public String addMovie(Movie movie) throws Exception {

		String movieStatus = movieDao.findMovie(movie.getMovieId());
		
		if(movieStatus.equals("Not Found")){
			throw new Exception("Service.MOVIE_UNAVAILABLE");
		}
		
		String movieId=movieDao.addMovie(movie);
		
		
		return movieId;
	}

	@Override
	public List<Movie> getMovies(Integer year) throws Exception {

		return movieDao.getMovies(year);
	}

	@Override
	public Integer updateRevenue(String movieId) throws Exception {

		return movieDao.updateRevenue(movieId);
	}

	
	@Override
	public Integer deleteMovie(String movieId) throws Exception {


		return movieDao.deleteMovie(movieId);
	}

}