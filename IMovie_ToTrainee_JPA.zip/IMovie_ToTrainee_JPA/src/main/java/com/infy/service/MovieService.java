package com.infy.service;

import com.infy.model.Movie;

public interface MovieService {


	public String addMovie(Movie movie) throws Exception;

	public Integer updateRevenue(String movieId) throws Exception;

	public Integer deleteMovie(String movieId) throws Exception;

}
