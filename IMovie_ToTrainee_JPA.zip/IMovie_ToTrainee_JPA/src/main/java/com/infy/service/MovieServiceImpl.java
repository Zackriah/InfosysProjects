package com.infy.service;

import com.infy.dao.MovieDAO;
import com.infy.dao.MovieDAOImpl;
import com.infy.model.Movie;


public class MovieServiceImpl implements MovieService {
	
	private MovieDAO movieDao=new MovieDAOImpl();
	

	@Override
	public String addMovie(Movie movie) throws Exception {

		String movieStatus = movieDao.findMovie(movie.getMovieId());
		
		if(movieStatus.equals("Not Found")){
			throw new Exception("Service.MOVIE_UNAVAILABLE");
		}
		
		String movieId=movieDao.addMovie(movie);
		
		
		return movieId;
	}

	@Override
	public Integer updateRevenue(String movieId) throws Exception {

		return movieDao.updateRevenue(movieId);
	}

	
	@Override
	public Integer deleteMovie(String movieId) throws Exception {


		return movieDao.deleteMovie(movieId);
	}

}