package com.infy;

import com.infy.model.Movie;
import com.infy.service.MovieService;
import com.infy.service.MovieServiceImpl;
import com.infy.utility.AppConfig;



public class UserInterface{

	public static MovieService service=new MovieServiceImpl();
	
	public static void main(String[] args) {
		addMovie();
		updateRevenue();
		deleteMovie();
		
		
	}
	
	public static void addMovie() {
		try {

			Movie movie = new Movie();

			movie.setMovieId("M1006");
			movie.setMovieName("3 Idiots");
			movie.setLanguage("Hindi");
			movie.setReleasedIn(2009);
			;
			movie.setRevenueInDollars(87000000);

			String movieId = service.addMovie(movie);
			System.out.println();
			System.out.print(AppConfig.PROPERTIES.getProperty("UserInterface.INSERT_SUCCESS"));
			System.out.println(movieId);

		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void updateRevenue() {
		try {

			Integer i = service.updateRevenue("M1005");
			System.out.println();
			if (i == 1) {
				System.out.print(AppConfig.PROPERTIES.getProperty("UserInterface.UPDATE_SUCCESS"));
			} else {
				System.out.print(AppConfig.PROPERTIES.getProperty("UserInterface.UPDATE_FAILURE"));
			}

		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void deleteMovie() {
		try {

			Integer i = service.deleteMovie("M1005");
			System.out.println();
			if (i == 1) {
				System.out.print(AppConfig.PROPERTIES.getProperty("UserInterface.DELETE_SUCCESS"));
			} else {
				System.out.print(AppConfig.PROPERTIES.getProperty("UserInterface.DELETE_FAILURE"));
			}

		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}


	
}

