package com.infy.dao;

import com.infy.model.Movie;



public class MovieDAOImpl implements MovieDAO {

	
	
	public String findMovie(String movieId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	public String addMovie(Movie movie) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	public Integer updateRevenue(String movieId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	public Integer deleteMovie(String movieId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}