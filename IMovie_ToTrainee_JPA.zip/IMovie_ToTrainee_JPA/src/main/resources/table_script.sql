DROP TABLE Movie CASCADE CONSTRAINTS;


CREATE TABLE Movie (
	movieId VARCHAR2(6) CONSTRAINT Movie_id_pk PRIMARY KEY,
	movieName VARCHAR2(50) CONSTRAINT jdbc NOT NULL,
	language VARCHAR2(10) CONSTRAINT jdbc_lang_nnull NOT NULL,
	releasedIn NUMBER(5) CONSTRAINT jdbc_release_nnull NOT NULL,
	revenueInDollars NUMBER(10) CONSTRAINT jdbc_revDollars_nnull NOT NULL
);



INSERT INTO Movie VALUES('M1001', 'Home Alone', 'English', 1990, 476700000);
INSERT INTO Movie VALUES('M1002', 'Home Alone', 'English', 1992, 358900000);
INSERT INTO Movie VALUES('M1003','Baby''s Day Out','English',1994, 16800000);
INSERT INTO Movie VALUES('M1004','Taare Zameen Par','Hindi', 2007, 13000000);
INSERT INTO Movie VALUES('M1005', 'Paa', 'Hindi', 2009, 4700000);