package com.infy.dao;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.infy.model.Customer;

@Repository(value = "customerDao")
public class CustomerDAOImpl implements CustomerDAO {

	@Autowired
	JdbcTemplate jdbcTemplate;

	public Integer addCustomer(Customer customer) {
		String sql = "INSERT INTO CUSTOMER (CUSTOMER_ID, EMAILID, NAME, DATE_OF_BIRTH) VALUES (?,?,?,?)";

		jdbcTemplate.update(sql, customer.getCustomerId(),
				customer.getEmailId(), customer.getName(),
				Date.valueOf(customer.getDateOfBirth()));
		return customer.getCustomerId();

	}

	public Customer getCustomer(Integer customerId) {
		String sql = "SELECT * from CUSTOMER where customer_id = ?";
		try {
			return jdbcTemplate.queryForObject(sql,	new Object[] { customerId }, new CustomerRowMapper());

		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}

	
	/*public List<Customer> getAllCustomers() {
		String query = "SELECT * FROM CUSTOMER";
		return jdbcTemplate.query(query, new CustomerRowMapper());
	}*/
	
	
	
	public List<Customer> findAllCustomers() {
		String query = "SELECT * FROM CUSTOMER";
		return jdbcTemplate.query(query, new CustomerRowMapper());
	}

	public String getCustomerName(Integer customerId) {
		String sql = "SELECT name from CUSTOMER where customer_id = ?";
		try {
			return jdbcTemplate.queryForObject(sql,	new Object[] {customerId}, String.class);

		} catch (EmptyResultDataAccessException e) {
			return null;
		}

	}
	
	public Integer deleteCustomer(Integer customerId) {
		String sql = "DELETE FROM CUSTOMER WHERE CUSTOMER_id = ?";
		return jdbcTemplate.update(sql, customerId);
	}

	public Integer updateCustomer(Integer customerId, String emailId) {
		String sql = "UPDATE CUSTOMER SET EMAILID = ? WHERE CUSTOMER_ID = ?";
		return jdbcTemplate.update(sql, emailId, customerId);
	}

	
}
