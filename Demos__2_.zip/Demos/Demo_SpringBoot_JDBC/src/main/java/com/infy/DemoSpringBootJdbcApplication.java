package com.infy;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;

import com.infy.model.Customer;
import com.infy.service.CustomerService;

@SpringBootApplication
public class DemoSpringBootJdbcApplication implements CommandLineRunner {

	@Autowired
	CustomerService customerService;

	@Autowired
	Environment environment;

	public static void main(String[] args) {
		SpringApplication.run(DemoSpringBootJdbcApplication.class, args);
	}

	public void run(String... args) throws Exception {
		//addCustomer();
		 //getCustomer();
		// getAllCustomers();
		// getCustomerName();
		 //updateCustomer();
	     deleteCustomer();

	}

	public void addCustomer() {
		Customer customer = new Customer();
		customer.setCustomerId(4);
		customer.setEmailId("Tim@infy.com");
		customer.setName("Tim Cook");
		customer.setDateOfBirth(LocalDate.now());

		try {
			Integer id = customerService.addCustomer(customer);
			System.out.println(environment
					.getProperty("UserInterface.INSERT_SUCCESS") + id);
		} catch (Exception e) {

			if (e.getMessage() != null)
				System.out
						.println(environment.getProperty(e.getMessage(),
								"Something went wrong. Please check log file for more details."));
		}

	}

	public void getCustomer() {
		try {

			Customer customer = customerService.getCustomer(4);

			System.out.println("Customer id : " + customer.getCustomerId());
			System.out.println("Customer name : " + customer.getName());
			System.out.println("Customer email : " + customer.getEmailId());

		} catch (Exception e) {

			if (e.getMessage() != null)
				System.out
						.println(environment.getProperty(e.getMessage(),
								"Something went wrong. Please check log file for more details."));
		}
	}

	public void getCustomerName() {
		try {
			Integer id = 4;
			String name = customerService.getCustomerName(id);

			System.out.println("Customer Id : " + id);
			System.out.println("Name : " + name);
		} catch (Exception e) {

			if (e.getMessage() != null)
				System.out
						.println(environment.getProperty(e.getMessage(),
								"Something went wrong. Please check log file for more details."));
		}
	}

	public void deleteCustomer() {
		try {
			customerService.deleteCustomer(4);
			System.out.println(environment
					.getProperty("UserInterface.DELETE_SUCCESS"));
		} catch (Exception e) {

			if (e.getMessage() != null)
				System.out
						.println(environment.getProperty(e.getMessage(),
								"Something went wrong. Please check log file for more details."));
		}
	}

	public void updateCustomer() {
		try {
			customerService.updateCustomer(4, "wjh@g.com");
			System.out.println(environment
					.getProperty("UserInterface.UPDATE_SUCCESS"));
		} catch (Exception e) {

			if (e.getMessage() != null)
				System.out
						.println(environment.getProperty(e.getMessage(),
								"Something went wrong. Please check log file for more details."));
		}
	}

	public void getAllCustomers() {
		try {
			List<Customer> customers = customerService.findAllCustomers();
			for (Customer customer : customers) {

				System.out.println("Customer id : " + customer.getCustomerId());
				System.out.println("Customer name : " + customer.getName());
				System.out.println("Customer email : " + customer.getEmailId());
				System.out
						.println("****************************************************");
			}
		} catch (Exception e) {

			if (e.getMessage() != null)
				System.out
						.println(environment.getProperty(e.getMessage(),
								"Something went wrong. Please check log file for more details."));
		}
	}
}
