package com.infy.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.infy.model.Customer;

class CustomerRowMapper implements RowMapper<Customer> {
	@Override
	public Customer mapRow(ResultSet rs, int rowNum) throws SQLException {
		Customer customer = new Customer();
		customer.setCustomerId(rs.getInt("CUSTOMER_ID"));
		customer.setEmailId(rs.getString("EMAILID"));
		customer.setName(rs.getString("NAME"));
		customer.setDateOfBirth(rs.getDate("DATE_OF_BIRTH").toLocalDate());
		return customer;
	}
}