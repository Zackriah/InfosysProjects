package com.infy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.CustomerDAO;
import com.infy.model.Customer;

@Service(value="customerService")
@Transactional(readOnly=true)
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerDAO customerDAO;



	@Transactional(readOnly=false,propagation=Propagation.REQUIRES_NEW)
	public Integer addCustomer(Customer customer) throws Exception {

		return customerDAO.addCustomer(customer);

	}



}
