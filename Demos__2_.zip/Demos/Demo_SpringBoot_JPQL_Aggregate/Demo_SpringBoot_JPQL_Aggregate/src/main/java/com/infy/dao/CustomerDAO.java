package com.infy.dao;


public interface CustomerDAO {

	public Double getAverageBalance() throws Exception;
	public Long getTotalBalance() throws Exception;
	public Long getNumberOfAccounts() throws Exception;
	public Integer getMinimumBalance() throws Exception;
	public Integer getMaximumBalance() throws Exception;
	
}
