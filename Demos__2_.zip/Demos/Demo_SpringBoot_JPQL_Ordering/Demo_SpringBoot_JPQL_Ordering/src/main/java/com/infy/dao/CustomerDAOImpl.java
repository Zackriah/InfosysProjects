package com.infy.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.infy.entity.AccountEntity;
import com.infy.entity.CustomerEntity;
import com.infy.model.Account;
import com.infy.model.Customer;


@Repository(value="customerDAO")
public class CustomerDAOImpl implements CustomerDAO {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<Customer> getSortedCustomerList() throws Exception {

		List<Customer> customerList=null;
		
		String queryString="SELECT c FROM CustomerEntity c ORDER BY c.name ASC";
		
//		String queryString="SELECT c FROM CustomerEntity c ORDER BY c.name DESC";
		
		Query query=entityManager.createQuery(queryString);
		
		List<CustomerEntity> result=query.getResultList();

		customerList=new ArrayList<Customer>();

		for (CustomerEntity customerEntity : result) {
			Customer customer=new Customer();
			customer.setCustomerId(customerEntity.getCustomerId());
			customer.setDateOfBirth(customerEntity.getDateOfBirth());
			customer.setEmailId(customerEntity.getEmailId());
			customer.setName(customerEntity.getName());

			List<AccountEntity> accountEntList=customerEntity.getAccountEntity();
			
			List<Account> accountList=new ArrayList<>();
			
			if(accountEntList!=null && !accountEntList.isEmpty()){
				for (AccountEntity accountEntity : accountEntList) {
					Account account=new Account();
					account.setAccountNumber(accountEntity.getAccountNumber());
					account.setAccountStatus(accountEntity.getAccountStatus());
					account.setAccountType(accountEntity.getAccountType());
					account.setBalance(accountEntity.getBalance());
					account.setOpeningDate(accountEntity.getOpeningDate());
					
					accountList.add(account);
					
				}
			}
			customer.setAccounts(accountList);
			
			customerList.add(customer);
		}
		
		return customerList;
	}

}
