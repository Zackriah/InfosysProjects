package com.infy.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.infy.entity.ServiceEntity;
import com.infy.entity.CustomerEntity;
import com.infy.model.Service;
import com.infy.model.Customer;

@Repository(value = "bankDAO")
public class BankDAOImpl implements BankDAO {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Integer addCustomerAndService(Customer customer) throws Exception {
		Integer customerId = null;

		List<Service> bankServices = customer.getBankServices();

		CustomerEntity customerEntity = new CustomerEntity();
		customerEntity.setDateOfBirth(customer.getDateOfBirth());
		customerEntity.setEmailId(customer.getEmailId());
		customerEntity.setName(customer.getName());

		List<ServiceEntity> bankServicesEntities = null;

		if (bankServices != null && !bankServices.isEmpty()) {

			bankServicesEntities = new ArrayList<ServiceEntity>();

			for (Service service : bankServices) {

				ServiceEntity servicesEntity = new ServiceEntity();
				servicesEntity.setServiceId(service.getServiceId());
				servicesEntity.setServiceName(service.getServiceName());
				servicesEntity.setServiceCost(service.getServiceCost());

				bankServicesEntities.add(servicesEntity);
			}

			customerEntity.setBankServices(bankServicesEntities);
		}
		
		entityManager.persist(customerEntity);
		
		customerId = customerEntity.getCustomerId();
		
		return customerId;
	}

	@Override
	public void addExistingServiceToExistingCustomer(Integer customerId,
			List<Integer> serviceIds) throws Exception {
		
		CustomerEntity customerEntity = entityManager.find(CustomerEntity.class, customerId);
		List<ServiceEntity> servicesEntityList = customerEntity.getBankServices();		
		for (Integer sId : serviceIds) {
			ServiceEntity servicesEntity = entityManager.find(ServiceEntity.class, sId);
			if (!servicesEntityList.contains(servicesEntity)) {
				servicesEntityList.add(servicesEntity);
			} 

		}
	}

	
	@Override
	public void deallocateServiceForExistingCustomer(Integer customerId,
			List<Integer> serviceIds) throws Exception {
		CustomerEntity customerEntity = entityManager.find(CustomerEntity.class, customerId);

		List<ServiceEntity> existingServiceList = customerEntity.getBankServices();
		
		for (Integer sId : serviceIds) {
			ServiceEntity serviceEntity=entityManager.find(ServiceEntity.class, sId);
			existingServiceList.remove(serviceEntity);
			
		}
	}

	@Override
	public void deleteCustomer(Integer customerId) throws Exception {

		CustomerEntity customerEntity = entityManager.find(
				CustomerEntity.class, customerId);

		customerEntity.setBankServices(null);

		entityManager.remove(customerEntity);

	}

	@Override
	public Customer getCustomer(Integer customerId) throws Exception {
		Customer customer = null;
		CustomerEntity customerEntity = entityManager.find(
				CustomerEntity.class, customerId);

		if (customerEntity != null) {
			customer = new Customer();
			customer.setCustomerId(customerEntity.getCustomerId());
			customer.setDateOfBirth(customerEntity.getDateOfBirth());
			customer.setEmailId(customerEntity.getEmailId());
			customer.setName(customerEntity.getName());

			List<ServiceEntity> bankServicesEntityList = customerEntity
					.getBankServices();
			List<Service> bankServicesList = new ArrayList<>();
			if (bankServicesEntityList != null
					&& !bankServicesEntityList.isEmpty()) {

				for (ServiceEntity bankServicesEnt : bankServicesEntityList) {

					Service services = new Service();
					services.setServiceId(bankServicesEnt.getServiceId());
					services.setServiceName(bankServicesEnt.getServiceName());
					services.setServiceCost(bankServicesEnt.getServiceCost());

					bankServicesList.add(services);
				}

				customer.setBankServices(bankServicesList);
			}
		}
		return customer;
	}

	@Override
	public Service getService(Integer serviceId) throws Exception {
		ServiceEntity serviceEntity = entityManager.find(ServiceEntity.class,
				serviceId);
		Service service = null;
		if (serviceEntity != null) {
			service = new Service();
			service.setServiceId(serviceEntity.getServiceId());
			service.setServiceName(serviceEntity.getServiceName());
			service.setServiceCost(serviceEntity.getServiceCost());
			
		}
		return service;
	}

}