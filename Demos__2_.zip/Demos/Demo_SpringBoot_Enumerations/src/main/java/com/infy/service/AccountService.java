package com.infy.service;

import com.infy.model.Account;


public interface AccountService {
	

	public String addAccount(Account account) throws Exception;

	
}