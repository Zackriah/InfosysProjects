drop table account cascade constraints;
drop table customer cascade constraints;
create table account (
	account_number number(10) not null,
	account_status varchar2(10),
	account_type varchar2(10),
	balance number(10),
	opening_date date,
	cust_id number(10),
	primary key (account_number)
);
create table customer (
	customer_id number(10) not null,
	city varchar2(10),
	date_of_birth date,
	emailid varchar2(20),
	name varchar2(20),
	primary key (customer_id)
);
alter table account add constraint fk_accnt_cust foreign key (cust_id) references customer;

insert into customer (customer_id, city, date_of_birth, emailid,name) values (1001,'MYSORE','10-Jan-1992','monica@infy.com','Monica');
insert into customer (customer_id, city, date_of_birth, emailid,name) values (1002,'MYSORE','23-Apr-1996','scott@infy.com','Scott');
insert into customer (customer_id, city, date_of_birth, emailid,name) values (1003,'MUMBAI','23-Oct-1994','james@infy.com','James');
insert into customer (customer_id, city, date_of_birth, emailid,name) values (1004,'MUMBAI','23-Aug-1991','roger@infy.com','Roger');
insert into customer (customer_id, city, date_of_birth, emailid,name) values (1005,'MUMBAI','01-Apr-1983','brad@infy.com','Brad');
insert into customer (customer_id, city, date_of_birth, emailid,name) values (1006,'CHENNAI','01-Jan-1992','patric@infy.com','Patric');


insert into account (account_number,account_status, account_type, balance, opening_date, cust_id) values (5001,'ACTIVE','Savings',12345,'25-Oct-2016',1001);
insert into account (account_number,account_status, account_type, balance, opening_date, cust_id) values (5002,'ACTIVE','Current',899567,'21-Jan-2015',1001);
insert into account (account_number,account_status, account_type, balance, opening_date, cust_id) values (5003,'INACTIVE','Loan',617345,'12-Nov-2016',1002);
insert into account (account_number,account_status, account_type, balance, opening_date, cust_id) values (5004,'ACTIVE','Savings',345324,'08-Dec-2017',1002);
insert into account (account_number,account_status, account_type, balance, opening_date, cust_id) values (5005,'ACTIVE','Demat',45324,'08-Apr-2017',1003);
insert into account (account_number,account_status, account_type, balance, opening_date, cust_id) values (5006,'ACTIVE','Demat',425324,'08-Mar-2018',1003);
insert into account (account_number,account_status, account_type, balance, opening_date, cust_id) values (5007,'INACTIVE','Loan',845324,'01-May-2018',1003);
insert into account (account_number,account_status, account_type, balance, opening_date, cust_id) values (5008,'ACTIVE','Credit Card',45987,'26-Jun-2017',1003);
insert into account (account_number,account_status, account_type, balance, opening_date, cust_id) values (5009,'ACTIVE','Current',2245324,'21-Aug-2017',1004);
insert into account (account_number,account_status, account_type, balance, opening_date, cust_id) values (5010,'INACTIVE','Savings',145924,'12-Dec-2013',1006);
insert into account (account_number,account_status, account_type, balance, opening_date, cust_id) values (5011,'ACTIVE','Demat',95324,'10-Nov-2016',1005);
insert into account (account_number,account_status, account_type, balance, opening_date, cust_id) values (5012,'INACTIVE','Demat',87324,'18-Jan-2016',1005);

commit;
