package com.infy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.CustomerDAO;
import com.infy.model.Customer;

@Service(value="customerService")
@Transactional
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerDAO customerDAO;


	//@Cacheable("customer")
	public Customer getCustomer(Integer customerId) throws Exception {

		Customer customer = customerDAO.getCustomer(customerId);

		//Customer customer2 = customerDAO.getCustomer(customerId);
		
		//System.out.println(customer1==customer2);
		
		
		return customer;
	}
}
