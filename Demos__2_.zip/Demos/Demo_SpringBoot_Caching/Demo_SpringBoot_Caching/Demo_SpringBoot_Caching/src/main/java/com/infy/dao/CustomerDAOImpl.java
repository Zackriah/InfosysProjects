package com.infy.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

import com.infy.entity.CustomerEntity;
import com.infy.model.Customer;

@Repository(value = "customerDAO")
public class CustomerDAOImpl implements CustomerDAO {

	@PersistenceContext
	private EntityManager entityManager;

	@Cacheable("customer")
	public Customer getCustomer(Integer customerId) throws Exception {

		Customer customer=null;

		
		CustomerEntity customerEntity = entityManager.find(CustomerEntity.class, customerId);
		if(customerEntity!=null){
			customer=new Customer();
			customer.setCustomerId(customerEntity.getCustomerId());
			customer.setDateOfBirth(customerEntity.getDateOfBirth());
			customer.setEmailId(customerEntity.getEmailId());
			customer.setName(customerEntity.getName());
		}

		return customer;
	}
}