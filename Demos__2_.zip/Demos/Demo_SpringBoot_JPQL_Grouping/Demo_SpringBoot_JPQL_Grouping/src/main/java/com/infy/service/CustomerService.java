package com.infy.service;

import java.util.List;


public interface CustomerService {

	public List<Object[]> getCustomerCountForCities() throws Exception;
	
}
