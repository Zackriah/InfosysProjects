package com.infy;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;

import com.infy.service.CustomerService;

@SpringBootApplication
public class DemoSpringBootJpqlGroupingApplication implements CommandLineRunner{

	@Autowired
	CustomerService service;
	@Autowired
	Environment environment;
	
	
	
	public static void main(String[] args) {
		SpringApplication.run(DemoSpringBootJpqlGroupingApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		getCityWiseCustomerCount();
		
	}

	public void getCityWiseCustomerCount() {
		try {
			List<Object[]> result=service.getCustomerCountForCities();
			System.out.println("City\t\tCount\n---------------------------------------------");
			for (Object[] obj : result) {
				System.out.println(obj[0]+"\t\t"+obj[1]);
			}
			
			
		} catch (Exception e) {
			String message = environment.getProperty(e.getMessage(),"Some exception occured. Please check log file for more details!!");
			System.out.println( message);

		}
		
	}

}

