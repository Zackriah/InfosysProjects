package com.infy.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;


@Repository(value="customerDAO")
public class CustomerDAOImpl implements CustomerDAO {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<Object[]> getCustomerCountForCities() throws Exception {

		String queryString="SELECT c.city, COUNT(c) FROM CustomerEntity c GROUP BY c.city";
		
//		String queryString="SELECT c.city, COUNT(c) FROM CustomerEntity c GROUP BY c.city HAVING c.city IN ('MYSORE','BANGALORE','pune')";
		
		
		Query query=entityManager.createQuery(queryString);
		
		List<Object[]> result=query.getResultList();
		
		return result;
	}

	



}
