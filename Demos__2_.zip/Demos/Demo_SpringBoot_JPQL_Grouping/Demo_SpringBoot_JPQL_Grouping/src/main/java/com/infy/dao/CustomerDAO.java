package com.infy.dao;

import java.util.List;


public interface CustomerDAO {

	public List<Object[]> getCustomerCountForCities() throws Exception;
	
	
}
